"""Unit tests: devig math, Kalshi fees, quoting pipeline, orderbook clamp,
paper-fill logic, secret scrubbing, and the two restart-safety guarantees.

Run:  cd kalshi-maker && python3 -m pytest tests/ -v
(pytest is a dev dependency only — not needed on Railway)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("MAKER_DB", "/tmp/test_maker.db")
os.environ.setdefault("ODDS_API_KEY", "testkey-abcdef123456")
os.environ.setdefault("DISCORD_WEBHOOK",
                      "https://discord.com/api/webhooks/123/secrettoken456")

if os.path.exists("/tmp/test_maker.db"):
    os.remove("/tmp/test_maker.db")

import pytest  # noqa: E402

import config as C  # noqa: E402
import store  # noqa: E402
from fair_value import american_to_prob, devig_two_way  # noqa: E402
from kalshi_client import kalshi_fee_cents  # noqa: E402
from notify import scrub  # noqa: E402
import quoter  # noqa: E402
from quoter import (desired_quotes, clamp_to_book, inventory_skew_cents,
                    maker_fee_cents)  # noqa: E402

store.init_db()


@pytest.fixture(autouse=True)
def _clean_quoter_state():
    quoter._fair_hist.clear()
    quoter._steam_until.clear()
    quoter.cooldowns.clear()
    yield


# ── devig math (item D17) ──────────────────────────────────────────────
def test_american_to_prob():
    assert american_to_prob(-110) == pytest.approx(110 / 210)
    assert american_to_prob(+150) == pytest.approx(100 / 250)
    assert american_to_prob(-100) == pytest.approx(0.5)


def test_devig_removes_vig():
    # -110/-110: raw probs sum to ~1.048; devig -> 50/50
    p = american_to_prob(-110)
    a, b = devig_two_way(p, p)
    assert a == pytest.approx(0.5)
    assert a + b == pytest.approx(1.0)


def test_devig_asymmetric():
    a, b = devig_two_way(american_to_prob(-150), american_to_prob(+130))
    assert a + b == pytest.approx(1.0)
    assert a > 0.55  # favorite stays favorite


def test_devig_degenerate():
    assert devig_two_way(0, 0) == (None, None)


# ── Kalshi fee formula: ceil(0.07 * C * P * (1-P)) to next cent ────────
def test_fee_known_values():
    assert kalshi_fee_cents(50, 100) == 175   # 0.07*100*.25 = $1.75
    assert kalshi_fee_cents(50, 1) == 2       # 0.0175 -> ceil -> 2c
    assert kalshi_fee_cents(10, 100) == 63    # 0.07*100*.09 = 0.63
    assert kalshi_fee_cents(99, 1) == 1       # tiny but never zero (ceil)


def test_fee_symmetry():
    assert kalshi_fee_cents(30, 10) == kalshi_fee_cents(70, 10)


# ── quoting pipeline ───────────────────────────────────────────────────
def _target(fair=0.55, mins_out=120):
    import datetime
    dt = datetime.datetime.now(datetime.timezone.utc) + \
        datetime.timedelta(minutes=mins_out)
    return {"ticker": "KXMLBGAME-TEST-NYY", "fair_prob": fair,
            "commence": dt.isoformat()}


def test_quotes_have_min_edge():
    for q in desired_quotes(_target()):
        assert q["edge"] >= C.MIN_EDGE_CENTS
        assert q["price"] <= q["fair"] - C.MARGIN_CENTS


def test_pull_inside_30_min():
    assert desired_quotes(_target(mins_out=C.PULL_MIN - 5)) == []


def test_widen_inside_60_min():
    normal = {q["side"]: q["price"] for q in desired_quotes(_target(mins_out=120))}
    near = {q["side"]: q["price"] for q in
            desired_quotes(_target(mins_out=C.WIDEN_MIN - 10))}
    for side in near:
        assert near[side] <= normal[side] - C.TIME_WIDEN_CENTS


def test_uncertainty_skip_and_widen():
    assert desired_quotes(_target(), uncertainty=C.UNC_SKIP + 0.001) == []
    normal = {q["side"]: q["price"] for q in desired_quotes(_target())}
    shaky = {q["side"]: q["price"] for q in
             desired_quotes(_target(), uncertainty=C.UNC_WIDEN + 0.001)}
    for side in shaky:
        assert shaky[side] <= normal[side] - C.UNC_WIDEN_CENTS


def test_inventory_skew_direction():
    # Long YES -> YES quote shades away (lower), NO quote tightens (higher)
    flat = {q["side"]: q["price"] for q in desired_quotes(_target())}
    long_yes = {q["side"]: q["price"] for q in desired_quotes(
        _target(), net_position={"net": 30, "cost": C.PER_MARKET_CAP})}
    assert long_yes["yes"] < flat["yes"]
    assert long_yes["no"] >= flat["no"]


def test_inventory_skew_scaling():
    assert inventory_skew_cents(0) == 0
    assert inventory_skew_cents(C.PER_MARKET_CAP) == C.MAX_INV_SKEW_CENTS
    assert 0 < inventory_skew_cents(C.PER_MARKET_CAP // 2) <= C.MAX_INV_SKEW_CENTS


def test_no_side_gets_more_size():
    qs = {q["side"]: q for q in desired_quotes(_target(fair=0.5))}
    assert qs["no"]["price"] * qs["no"]["count"] > \
        qs["yes"]["price"] * qs["yes"]["count"]


# ── orderbook clamp (item C14) ─────────────────────────────────────────
def test_clamp_never_crosses():
    # book: best NO bid 52 -> implied YES ask = 48. Our 50c YES bid crosses.
    q = {"side": "yes", "price": 50, "count": 10, "fair": 55.0, "edge": 4.0}
    book = {"yes": [[44, 100]], "no": [[52, 100]]}
    q2, ctx = clamp_to_book(q, book)
    assert q2["price"] == 47  # implied ask 48 -> clamped to 47
    assert ctx["clamped"] is True


def test_clamp_drops_when_edge_dies():
    q = {"side": "yes", "price": 50, "count": 10, "fair": 51.0, "edge": 1.0}
    book = {"yes": [], "no": [[55, 100]]}  # implied ask 45, fair 51 -> 44 bid
    q2, ctx = clamp_to_book(q, book)
    # 44 bid vs fair 51 leaves plenty of edge -> kept and clamped
    assert q2 is not None and q2["price"] == 44
    # now a book so tight there's no room at all
    book2 = {"yes": [], "no": [[98, 100]]}
    q3, ctx3 = clamp_to_book({"side": "yes", "price": 50, "count": 10,
                              "fair": 51.0, "edge": 1.0}, book2)
    assert q3 is None


def test_clamp_queue_context():
    q = {"side": "yes", "price": 44, "count": 10, "fair": 55.0, "edge": 9.0}
    book = {"yes": [[44, 250], [40, 50]], "no": [[50, 100]]}
    q2, ctx = clamp_to_book(q, book)
    assert q2["price"] == 44
    assert ctx["queue_ahead"] == 250
    assert ctx["best_bid"] == 44


def test_clamp_unavailable_book_passes_through():
    q = {"side": "no", "price": 40, "count": 5, "fair": 45.0, "edge": 4.0}
    q2, ctx = clamp_to_book(q, {})
    assert q2 == q and ctx["book"] == "unavailable"


# ── restart safety (item A3) ───────────────────────────────────────────
def test_fair_refresh_on_kept_orders_after_restart():
    """Simulate restart: a reconciled order has fair=None. One sync pass
    with an identical desired quote must re-arm fair (move trigger)."""
    from main import Maker
    m = Maker.__new__(Maker)  # no network in __init__
    m.live = {"oid1": {"ticker": "T", "side": "yes", "price": 44,
                       "count": 10, "fair": None}}

    class NoopClient:
        def cancel_order(self, oid):
            raise AssertionError("must not cancel a kept order")

        def get_orderbook(self, *a, **k):
            return {}

        def place_limit(self, *a, **k):
            raise AssertionError("must not post — already have it")

    m.client = NoopClient()
    want = {("T", "yes"): {"ticker": "T", "side": "yes", "price": 44,
                           "count": 10, "fair": 47.0, "edge": 3.0}}
    m.sync_quotes(want, exposure=0)
    assert m.live["oid1"]["fair"] == 47.0  # re-armed


def test_settlement_polling_gated_until_primed():
    """poll_settlements must be a no-op (re-attempt priming only) until
    priming has succeeded — old settlements can never hit today's P&L."""
    from main import Maker
    m = Maker.__new__(Maker)
    m.settlements_primed = False
    m._settle_log = []
    calls = {"prime": 0}
    m.prime_settlements = lambda: calls.__setitem__("prime", calls["prime"] + 1)

    class BoomClient:
        def get_settlements(self, **k):
            raise AssertionError("must not fetch settlements before priming")

    m.client = BoomClient()
    m.poll_settlements()
    assert calls["prime"] == 1


def test_priming_dedupes_old_settlements():
    sid = "OLDGAME-123settled"
    assert store.record_settlement(sid, "OLDGAME-123", "yes", 100, 90, 0,
                                   "2026-07-01") is True
    # second attempt (post-restart poll) must be rejected -> P&L untouched
    assert store.record_settlement(sid, "OLDGAME-123", "yes", 100, 90, 10,
                                   "2026-07-01") is False


# ── paper-mode fill simulation (item C15) ──────────────────────────────
def test_sim_fill_on_trade_through():
    from paper import PaperEngine
    pe = PaperEngine.__new__(PaperEngine)
    pe.orders = {"sim-1": {"ticker": "T", "side": "yes", "price": 44,
                           "count": 10, "fair": 48.0}}
    pe.positions = {}
    pe._seen_trades = set()
    pe.last_trade_ts = 0

    class FakeClient:
        def get_trades(self, tkr, min_ts=None):
            # taker sold YES down to 43c -> our 44c bid would have filled
            return [{"trade_id": "t1", "taker_side": "no",
                     "yes_price": 43, "count": 4}]

    fills = pe.poll_trades(FakeClient())
    assert len(fills) == 1
    assert fills[0]["count"] == 4 and fills[0]["price"] == 44
    assert pe.orders["sim-1"]["count"] == 6
    assert pe.positions["T"]["yes"][0] == 4


def test_sim_no_fill_when_print_above_bid():
    from paper import PaperEngine
    pe = PaperEngine.__new__(PaperEngine)
    pe.orders = {"sim-1": {"ticker": "T", "side": "yes", "price": 44,
                           "count": 10, "fair": 48.0}}
    pe.positions = {}
    pe._seen_trades = set()
    pe.last_trade_ts = 0

    class FakeClient:
        def get_trades(self, tkr, min_ts=None):
            # trade at 46 never reached our 44 bid; taker BUYING yes
            # (taker_side yes) hits NO bids, not ours
            return [{"trade_id": "t2", "taker_side": "no",
                     "yes_price": 46, "count": 4},
                    {"trade_id": "t3", "taker_side": "yes",
                     "yes_price": 40, "count": 4}]

    assert pe.poll_trades(FakeClient()) == []
    assert pe.orders["sim-1"]["count"] == 10


# ── maker CLV math (item B7) ───────────────────────────────────────────
def test_maker_clv_math():
    store.record_fair_value("CLVTEST", 0.60, 3, True, 0.01, "2026-07-20T23:00:00Z")
    store.record_fill("f-yes", "CLVTEST", "yes", 55, 10, fair_at_fill=58.0,
                      edge_at_fill=3.0, fee_cents=5)
    store.record_fill("f-no", "CLVTEST", "no", 37, 10, fair_at_fill=42.0,
                      edge_at_fill=5.0, fee_cents=5)
    rows = {r["fill_id"]: r for r in store.compute_clv_for_ticker("CLVTEST")}
    # close fair YES = 60c -> yes fill @55 = +5; NO fair = 40c -> no @37 = +3
    assert rows["f-yes"]["edge_vs_close"] == pytest.approx(5.0)
    assert rows["f-no"]["edge_vs_close"] == pytest.approx(3.0)


# ── secret scrubbing (item D18) ────────────────────────────────────────
def test_scrub_removes_secrets():
    key = os.environ["ODDS_API_KEY"]
    msg = (f"error at https://api.the-odds-api.com/v4?apiKey={key}&x=1 "
           f"webhook https://discord.com/api/webhooks/123/secrettoken456")
    out = scrub(msg)
    assert key not in out
    assert "secrettoken456" not in out
    assert "[REDACTED]" in out


def test_scrub_removes_pem():
    pem = "-----BEGIN RSA PRIVATE KEY-----\nMIIabc\n-----END RSA PRIVATE KEY-----"
    assert "MIIabc" not in scrub(f"failed to load: {pem}")


# ── v4.1 edge add-ons ──────────────────────────────────────────────────
def test_longshot_extra_edge():
    """Bids in longshot territory must clear a higher edge bar."""
    quoter._fair_hist.clear(); quoter._steam_until.clear()
    # fair 18c for YES side -> longshot; NO side is an 82c favorite
    qs = {q["side"]: q for q in desired_quotes(_target(fair=0.18))}
    if "yes" in qs:
        assert qs["yes"]["edge"] >= C.MIN_EDGE_CENTS + C.LONGSHOT_EXTRA_EDGE
    assert "no" in qs  # favorite side quotes at standard edge
    assert qs["no"]["edge"] >= C.MIN_EDGE_CENTS


def test_steam_guard_pauses_market():
    quoter._fair_hist.clear(); quoter._steam_until.clear()
    t = _target(fair=0.50)
    assert desired_quotes(t) != []           # calm: quotes out
    t2 = dict(t); t2["fair_prob"] = 0.54     # 4c jump inside the window
    assert desired_quotes(t2) == []          # steaming: pulled
    assert desired_quotes(t2) == []          # stays paused
    quoter._fair_hist.clear(); quoter._steam_until.clear()


def test_steam_guard_ignores_slow_drift():
    quoter._fair_hist.clear(); quoter._steam_until.clear()
    import quoter as qmod
    t = _target(fair=0.50)
    assert desired_quotes(t) != []
    # age the history out of the window, then a small move
    qmod._fair_hist[t["ticker"]] = [(0, 50.0)]
    t2 = dict(t); t2["fair_prob"] = 0.52
    assert desired_quotes(t2) != []          # 2c after window reset: fine
    quoter._fair_hist.clear(); quoter._steam_until.clear()


# ── v4.2 fair-value quality ────────────────────────────────────────────
def test_power_devig_sums_to_one():
    from fair_value import devig_power
    a, b = devig_power(american_to_prob(-250), american_to_prob(+210))
    assert a + b == pytest.approx(1.0, abs=1e-6)


def test_power_devig_shrinks_longshot_vs_multiplicative():
    """On a lopsided line, power devig gives the favorite MORE and the
    longshot LESS than multiplicative — correcting longshot overstatement."""
    from fair_value import devig_power
    ph, pd = american_to_prob(-300), american_to_prob(+240)
    mh, md = devig_two_way(ph, pd)
    kh, kd = devig_power(ph, pd)
    assert kh > mh and kd < md


def test_power_devig_even_line_unchanged():
    from fair_value import devig_power
    p = american_to_prob(-110)
    a, b = devig_power(p, p)
    assert a == pytest.approx(0.5, abs=1e-6)


def test_median_consensus_robust_to_outlier():
    probs = [0.55, 0.56, 0.54, 0.80]  # one stale/outlier book
    import statistics
    med = statistics.median(probs)
    mean = sum(probs) / len(probs)
    assert abs(med - 0.555) < 0.01 and mean > 0.60  # median ignores outlier


# ── v4.3 practitioner fixes ────────────────────────────────────────────
def test_maker_fee_exact_formula():
    """Maker fee = ceil(0.0175 x C x P x (1-P)), matching Kalshi's
    published schedule: 200 @ 50c -> $0.88, 1 @ 50c -> 1c (not 0.5c)."""
    from kalshi_client import kalshi_maker_fee_cents
    assert kalshi_maker_fee_cents(50, 200) == 88
    assert kalshi_maker_fee_cents(50, 1) == 1
    assert kalshi_maker_fee_cents(40, 30) == 13   # 0.0175*30*.24=$0.126
    # rounding order matters: 0.25 x ceil'd taker fee would give 0.5c/12.75c
    assert kalshi_maker_fee_cents(50, 1) != kalshi_fee_cents(50, 1) * 0.25


def test_adaptive_cadence_config():
    assert C.FAST_LOOP_SECS < C.LOOP_SECS
    assert C.FAST_WINDOW_MIN >= C.WIDEN_MIN
