"""All tunable constants in one place. Every value is env-overridable.

Money values are CENTS unless the name says otherwise.
Change a value here (or set the env var on Railway) — nothing else to edit.
"""
import logging
import os


def _i(name: str, default: int) -> int:
    return int(os.environ.get(name, str(default)))


def _f(name: str, default: float) -> float:
    return float(os.environ.get(name, str(default)))


def _s(name: str, default: str) -> str:
    return os.environ.get(name, default)


# ── identity / endpoints ───────────────────────────────────────────────
KALSHI_BASE_URL   = _s("KALSHI_BASE_URL", "https://api.elections.kalshi.com/trade-api/v2")
KALSHI_SERIES     = _s("KALSHI_SERIES", "KXMLBGAME")
DISCORD_WEBHOOK   = _s("DISCORD_WEBHOOK", "")

# ── risk caps ──────────────────────────────────────────────────────────
PER_MARKET_CAP    = _i("PER_MARKET_CAP", 2000)     # $20 max cost basis per market
TOTAL_CAP         = _i("TOTAL_CAP", 40000)         # $400 max total working capital
DAILY_LOSS_LIMIT  = _i("DAILY_LOSS_LIMIT", 6000)   # $60 realized loss -> halt for the day
DRAWDOWN_LIMIT    = _i("DRAWDOWN_LIMIT", 20000)    # $200 equity drawdown -> hard kill
START_BANKROLL    = _i("START_BANKROLL", 50000)    # $500; set to actual deposit

# ── quoting: edge & spread ─────────────────────────────────────────────
MIN_EDGE_CENTS    = _i("MIN_EDGE_CENTS", 3)   # required edge after fees, normal side
OFFSET_MIN_EDGE   = _i("OFFSET_MIN_EDGE", 1)  # relaxed edge floor on the side that FLATTENS inventory
MARGIN_CENTS      = _i("MARGIN_CENTS", 4)     # never post closer than this to fair
REQUOTE_MOVE      = _i("REQUOTE_MOVE", 2)     # cancel/re-quote if fair moved this many cents

# ── quoting: sizing ────────────────────────────────────────────────────
NO_SIZE_PCT       = _i("NO_SIZE_PCT", 60)     # % of per-market cap to the NO side
                                              # (retail overbets YES; surplus is on NO)

# ── timing windows (minutes to first pitch) ────────────────────────────
MAX_HOURS_OUT     = _i("MAX_HOURS_OUT", 48)   # don't quote games further out than this
WIDEN_MIN         = _i("WIDEN_MIN", 60)       # inside 60m: widen quotes (pre-game vol)
TIME_WIDEN_CENTS  = _i("TIME_WIDEN_CENTS", 2) # extra margin applied inside WIDEN_MIN
PULL_MIN          = _i("PULL_MIN", 30)        # inside 30m: pull all quotes entirely
                                              # (replaces old CUTOFF_MIN)

# ── uncertainty filter (book disagreement, prob points 0-1) ────────────
# stddev of devigged home-prob across books used for consensus
UNC_WIDEN         = _f("UNC_WIDEN", 0.015)    # >1.5c disagreement: widen quotes
UNC_WIDEN_CENTS   = _i("UNC_WIDEN_CENTS", 2)  # extra margin when widening
UNC_SKIP          = _f("UNC_SKIP", 0.030)     # >3c disagreement: skip market entirely
MIN_BOOKS         = _i("MIN_BOOKS", 2)        # need at least this many books for a fair

# ── inventory skew ─────────────────────────────────────────────────────
MAX_INV_SKEW_CENTS = _i("MAX_INV_SKEW_CENTS", 3)  # max cents of shading from inventory
# skew scales linearly with |position cost| / PER_MARKET_CAP up to the max.
FILL_COOLDOWN_SECS = _i("FILL_COOLDOWN_SECS", 600)  # pause re-quoting a filled side

# ── fees ───────────────────────────────────────────────────────────────
# Kalshi taker fee = ceil(0.07 * C * P * (1-P)). Most series charge resting
# (maker) orders nothing; 0.25 multiplier is a conservative default.
MAKER_FEE_MULT    = _f("MAKER_FEE_MULT", 0.25)

# ── odds api ───────────────────────────────────────────────────────────
ODDS_API_KEY      = _s("ODDS_API_KEY", "")
ODDS_SPORT        = _s("ODDS_SPORT", "baseball_mlb")
ODDS_REGIONS      = _s("ODDS_REGIONS", "us,eu")
# Credit math: calls cost (markets x regions-groups) = 2 credits with us,eu.
#   CACHE=90s -> ~57.6K credits/mo   CACHE=60s -> ~86.4K/mo (fits 100K tier
#   with room for the bet tracker)   CACHE=30s -> ~172K/mo (DOES NOT FIT).
ODDS_CACHE_SECS   = _i("ODDS_CACHE_SECS", 60)
STALE_FAIR_SECS   = _i("STALE_FAIR_SECS", 240)  # cancel everything if feed this stale
QUOTA_ALERT_REMAINING = _i("QUOTA_ALERT_REMAINING", 8000)  # Discord alert below this

# ── kalshi rate limits (basic tier: ~10 read/s, ~5 transactions/s) ─────
# We pace below the published caps. Verify your tier at
# https://trading-api.readme.io/reference/tiers if you upgrade.
READ_RPS          = _f("READ_RPS", 8.0)
WRITE_RPS         = _f("WRITE_RPS", 4.0)

# ── ops ────────────────────────────────────────────────────────────────
LOOP_SECS         = _i("LOOP_SECS", 30)
WATCHDOG_STALL_SECS = _i("WATCHDOG_STALL_SECS", 300)   # alert if loop silent 5 min
WATCHDOG_REALERT_SECS = _i("WATCHDOG_REALERT_SECS", 900)
PAPER_MODE        = os.environ.get("KILL", "") == "1"  # KILL=1 -> paper trading
ORDERBOOK_DEPTH   = _i("ORDERBOOK_DEPTH", 10)

# ── storage ────────────────────────────────────────────────────────────
DB_PATH = _s("MAKER_DB", "/data/maker.db")
if not os.path.isdir(os.path.dirname(DB_PATH) or "."):
    logging.getLogger("config").warning(
        f"{os.path.dirname(DB_PATH)} not mounted — falling back to ./maker.db "
        "(state will NOT survive redeploys; mount a Railway volume at /data)")
    DB_PATH = "./maker.db"

# ── edge research add-ons (v4.1) ───────────────────────────────────────
# Favorite-longshot bias (Bürgi/Deng/Whelan, 300K+ Kalshi contracts):
# low-priced contracts win LESS often than price implies (<10c contracts
# lose >60% of money); high-priced contracts earn small positive returns.
# So: demand extra edge when our bid would be a longshot price, and let
# favorite-side bids through at standard edge.
LONGSHOT_CENTS    = _i("LONGSHOT_CENTS", 25)     # a bid below this is a longshot
LONGSHOT_EXTRA_EDGE = _i("LONGSHOT_EXTRA_EDGE", 2)  # extra required edge there

# Steam guard: MLB fairs move fastest on lineup posts (~3-5h out) and
# pitcher scratches (20-30c swings). If OUR fair moved fast recently, the
# market is repricing — resting quotes are pick-off bait. Pause the market.
STEAM_WINDOW_SECS = _i("STEAM_WINDOW_SECS", 180)
STEAM_MOVE_CENTS  = _f("STEAM_MOVE_CENTS", 3.0)  # move within window -> pause
STEAM_PAUSE_SECS  = _i("STEAM_PAUSE_SECS", 240)

# ── v4.2 fair-value quality ────────────────────────────────────────────
# Multiplicative devig is known to overstate longshot probabilities on
# lopsided lines; the power method (solve k: pa^k + pb^k = 1) corrects it.
# Since Kalshi's longshot side is the trap side, sharper fairs on big
# favorites matter. Options: "power" | "multiplicative"
DEVIG_METHOD      = _s("DEVIG_METHOD", "power")
# Cross-book consensus: median is robust to one stale/outlier book
# dragging the fair. Options: "median" | "mean"
CONSENSUS         = _s("CONSENSUS", "median")

# ── v4.3 practitioner fixes ────────────────────────────────────────────
# REST polling staleness is the documented pick-off vector for Kalshi bots
# ("you're trading prices already stale when your order lands"). When any
# matched game is inside FAST_WINDOW_MIN of first pitch, tighten the loop.
FAST_WINDOW_MIN   = _i("FAST_WINDOW_MIN", 120)
FAST_LOOP_SECS    = _i("FAST_LOOP_SECS", 12)
